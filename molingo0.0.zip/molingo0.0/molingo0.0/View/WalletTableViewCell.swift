//
//  WalletTableViewCell.swift
//  molingo0.0
//
//  Created by Viola An on 9/14/22.
//

import UIKit

class WalletTableViewCell: UITableViewCell {


    @IBOutlet weak var tokenlabel: UILabel!
    @IBOutlet weak var avaxlabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    // Set up wallet values
    func setCellWithValuesOf(_ wallet: Wallet) {
        tokenlabel.text = wallet.token
        avaxlabel.text = wallet.avax

    }

}
