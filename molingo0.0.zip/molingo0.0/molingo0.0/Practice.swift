//
//  Practice.swift
//  molingo0.0
//
//  Created by Viola An on 9/9/22.
//

import UIKit

class Practice: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

