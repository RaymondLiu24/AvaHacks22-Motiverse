//
//  SQLiteCommands.swift
//  molingo0.0
//
//  Created by Viola An on 9/12/22.
//
// Wallet--model--purple S, wallet--the table name--green L

import Foundation
import SQLite
import SQLite3

class SQLiteCommands {
    
    static var table = Table("wallet")
    
    // Expressions
    static let id = Expression<Int>("id")
    static let token = Expression<String>("token")
    static let avax = Expression<String>("avax")
    

    
    // Creating Table
    static func createTable() {
        guard let database = SQLiteDatabase.sharedInstance.database else {
            print("Datastore connection error")
            return
        }
        
        do {
            // ifNotExists: true - Will NOT create a table if it already exists
            try database.run(table.create(ifNotExists: true) { table in
                table.column(id, primaryKey: true)
                table.column(token)
                table.column(avax)
            })
        } catch {
            print("Table already exists: \(error)")
        }
    }
    
    // Inserting Row
    static func insertRow(_ walletValues:Wallet) -> Bool? {
        guard let database = SQLiteDatabase.sharedInstance.database
        else {
            print("Datastore connection error")
            return nil
        }
        
        do {
            try database.run(table.insert(id <- walletValues.id,token <- walletValues.token, avax <- walletValues.avax))
            print("insertrow")
            return true
        } catch let Result.error(message, code, statement) where code == SQLITE_CONSTRAINT {
            print("Insert row failed: \(message), in \(String(describing: statement))")
            return false
        } catch let error {
            print("Insertion failed: \(error)")
            return false
        }
    }
    // Updating Row
    static func updateRow(_ walletValues: Wallet) -> Bool? {
        guard let database = SQLiteDatabase.sharedInstance.database else {
            print("Datastore connection error")
            return nil
        }
        
        // Extracts the appropriate wallet from the table according to the id
        let wallet = table.filter(id == walletValues.id).limit(1)
        
        do {
            // Update the contact's values
            if try database.run(wallet .update(id <- walletValues.id,token <- walletValues.token, avax <- walletValues.avax)) > 0 {
                print("Updated wallet")
                return true
            } else {
                print("Could not update wallet: wallet not found")
                return false
            }
        } catch let Result.error(message, code, statement) where code == SQLITE_CONSTRAINT {
            print("Update row faild: \(message), in \(String(describing: statement))")
            return false
        } catch let error {
            print("Updation failed: \(error)")
            return false
        }
    }

    // Present Rows
    static func presentRows() -> [Wallet]? {
        guard let database = SQLiteDatabase.sharedInstance.database else {
            print("Datastore connection error")
            return nil
        }
        
        // Wallet Array
        var walletArray = [Wallet]()
        
        // Sorting data in descending order by ID
        table = table.order(id.desc)
        
        do {
            for wallet in try database.prepare(table) {
                
                let idValue = wallet[id]
                let tokenValue = wallet[token]
                let avaxValue = wallet[avax]
                
                // Create object
               let walletObject = Wallet ( id: idValue, token: tokenValue, avax: avaxValue)
                
                // Add object to an array
                walletArray.append(walletObject)
                
                print("id \(wallet[id]), token: \(wallet[token]), avax: \(wallet[avax])")
                print("roll presented")
            }
        } catch {
            print("Present row error: \(error)")
        }
        return walletArray
    }
    // Delete Row
    static func deleteRow(walletId: Int) {
        guard let database = SQLiteDatabase.sharedInstance.database else {
            print("Datastore wallet error")
            return
        }
        
        do {
            let wallet = table.filter(id == walletId).limit(1)
            try database.run(wallet.delete())
        } catch {
            print("Delete row error: \(error)")
        }
    }
}
