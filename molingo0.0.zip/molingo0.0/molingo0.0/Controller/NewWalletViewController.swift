
import UIKit

class NewWalletViewController: UIViewController {
    

    @IBOutlet weak var TokenTextField: UITextField!
    @IBOutlet weak var AVAXTextField: UITextField!
    
    var viewModel: NewWalletViewModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        createTable()
        setUpViews()
        TokenTextField.becomeFirstResponder()
//        AVAXTextField.delegate = self
    }
    // MARK: - Connect to database and create table.
    private func createTable() {
        let database = SQLiteDatabase.sharedInstance
        database.createTable()
        print("table created in new wallet view controller")
    }
    
    // MARK: - Setup the views with the values of the selected contact
    private func setUpViews() {
        if let viewModel = viewModel {
            TokenTextField.text = viewModel.token
            AVAXTextField.text = viewModel.avax
            print("view set up")
        }
    }
    // MARK: - Save new contact or update an existing contact
    @IBAction func transfer(_ sender: Any) {
        print("new wallet info")
        let id: Int = viewModel == nil ? 0 : viewModel.id!
        let token = TokenTextField.text ?? ""
        let avax = AVAXTextField.text ?? ""

        
        let walletValues = Wallet(id: id, token: token, avax: avax)
        
        // If viewModel equal to nil a new contact will be created, otherwise an existing contact will be updated.
        if viewModel == nil {
            // Contact created
            createNewWallet(walletValues)
            print("new wallet info sent")
        } else {
            // Contact updated
            updateWallet(walletValues)
        }
    }
    
    // MARK: - Create new wallet
    private func createNewWallet(_ walletValues:Wallet) {
        let walletAddedToTable = SQLiteCommands.insertRow(walletValues)
        
        // Phone number is unique to each contact so we check if it already exists
        if walletAddedToTable == true {
            dismiss(animated: true, completion: nil)
        }else {
            showError("Error", message: "This contact cannot be created because this phone number already exist in your contact list.")
        }
    }
    
    // MARK: - Update wallet
    private func updateWallet(_ walletValues: Wallet) {
        let walletUpdatedInTable = SQLiteCommands.updateRow(walletValues)
        
        // Phone number is unique to each contact so we check if it already exists
        if walletUpdatedInTable == true {
            if let cellClicked = navigationController {
                cellClicked.popViewController(animated: true)
            }else {
                showError("Error", message: "This contact cannot be created because this phone number already exist in your contact list.")
            }
        } 
    }
    
    
    @IBAction func cancelButton(_ sender: Any) {
        let addButtonClicked = presentingViewController is UINavigationController
        // If the user clicked add button on the previous screen
        if addButtonClicked {
            // Dismisses back to the previous screen with animation
            dismiss(animated: true, completion: nil)
        }
        // If the user clicked on a cell on the previous screen
        else if let cellClicked = navigationController {
            cellClicked.popViewController(animated: true)
        } else {
            print("The ContactScreenTableViewController is not inside a navigation controller")
        }

    }
}

  
