//
//  WalletScreenTableViewController.swift
//  molingo0.0
//
//  Created by Viola An on 9/15/22.
//

import UIKit

class WalletScreenTableViewController: UITableViewController {

    private var viewModel = WalletScreenViewModel()

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Wallet"
        
        // Connect to database.
        viewModel.connectToDatabase()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        loadData()
        tableView.reloadData()
    }
    

    // MARK: - Load data from SQLite database
    private func loadData() {
        viewModel.loadDataFromSQLiteDatabase()
    }

    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.numberOfRowsInSection(section: section)
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)

        // Configure the cell...
        let object = viewModel.cellForRowAt(indexPath: indexPath)
        
        if let walletCell = cell as? WalletTableViewCell {
            walletCell.setCellWithValuesOf(object)
        }
        return cell
    }

    // Delete cell from table
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let wallet = viewModel.cellForRowAt(indexPath: indexPath)
            
            // Delete contact from database table
            SQLiteCommands.deleteRow(walletId: wallet.id)
            
            // Updates the UI after delete changes
            self.loadData()
            self.tableView.reloadData()
        }
    }
    
    // MARK: - Navigation

    // Passes selected contact from table cell to NewContactViewController
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Pass the selected object to the new view controller.
        if segue.identifier == "editWallet" {
            guard let newWalletVC = segue.destination as? NewWalletViewController else {return}
            guard let selectedWalletCell = sender as? WalletTableViewCell else {return}
            if let indexPath = tableView.indexPath(for: selectedWalletCell) {
                let selectedWallet = viewModel.cellForRowAt(indexPath: indexPath)
                newWalletVC.viewModel = NewWalletViewModel(walletValues: selectedWallet)
            }
        }
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
