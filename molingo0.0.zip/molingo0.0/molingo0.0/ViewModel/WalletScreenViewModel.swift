//
//  WalletScreenViewModel.swift
//  molingo0.0
//
//  Created by Viola An on 9/15/22.
//

import Foundation

class WalletScreenViewModel {
    
    private var walletArray = [Wallet]()
    
    func connectToDatabase() {
        _ = SQLiteDatabase.sharedInstance
    }
    
    func loadDataFromSQLiteDatabase() {
        walletArray = SQLiteCommands.presentRows() ?? []
    }
    
    func numberOfRowsInSection (section: Int)  -> Int {
        if walletArray.count != 0 {
            return walletArray.count
        }
        return 0
    }
    
    func cellForRowAt (indexPath: IndexPath) -> Wallet {
        return walletArray[indexPath.row]
    }
}
