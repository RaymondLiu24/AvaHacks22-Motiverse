//
//  NewWalletViewModel.swift
//  molingo0.0
//
//  Created by Viola An on 9/12/22.
//

import UIKit

class NewWalletViewModel {
    
    private var walletValues: Wallet?
    
    let id: Int?
    let token: String?
    let avax: String?
    
    init(walletValues: Wallet?) {
//        self.walletValues = walletValues assigning a property to itself problem
        
        self.id = walletValues?.id
        self.token = walletValues?.token
        self.avax = walletValues?.avax
        
    }
}
