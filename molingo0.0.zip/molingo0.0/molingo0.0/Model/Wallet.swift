//
//  Wallet.swift
//  molingo0.0
//
//  Created by Viola An on 9/11/22.
//

import Foundation

struct Wallet {
    //Variables
    let id: Int
    let token: String
    let avax: String
    
    
}
